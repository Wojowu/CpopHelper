Huge thanks to:
Vividescence for encouragement in starting this project.
Kalobi, SSM24, Microlith57, and XMinty7 for technical help.
Vickyy for (jokingly) suggesting the name.

This is my first real programming project, any feedback is appreciated.

Feel free to reuse the code, as long as you credit appropriately.

Use at your own risk.

:catbus: